export declare const loadRegisteredDiagrams: () => Promise<void>;
