export declare const addDiagrams: () => void;
