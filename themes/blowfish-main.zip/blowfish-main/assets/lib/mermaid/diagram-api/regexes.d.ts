export declare const frontMatterRegex: RegExp;
export declare const directiveRegex: RegExp;
export declare const anyCommentRegex: RegExp;
