import type { FlowchartDiagramConfig } from '../config.type.js';
export declare const getSubGraphTitleMargins: ({ flowchart, }: {
    flowchart: FlowchartDiagramConfig;
}) => {
    subGraphTitleTopMargin: number;
    subGraphTitleBottomMargin: number;
    subGraphTitleTotalMargin: number;
};
