/**
 * Sanitizes directive objects
 *
 * @param args - Directive's JSON
 */
export declare const sanitizeDirective: (args: any) => void;
export declare const sanitizeCss: (str: string) => string;
