export declare const convert: (template: TemplateStringsArray, ...params: unknown[]) => {
    [k: string]: unknown;
}[];
