/**
 * Values that have been hardcoded in src/diagrams/er/styles.js. These can be used by
 *   theme-_._ files to maintain display styles until themes, styles, renderers are revised. --
 *   2022-09-22
 */
export declare const oldAttributeBackgroundColorOdd = "#ffffff";
export declare const oldAttributeBackgroundColorEven = "#f2f2f2";
