export function mkBorder(col: any, darkMode: any): any;
