import type { Direction } from '../../src/diagrams/block/blockTypes.js';
export declare const getArrowPoints: (duplicatedDirections: Direction[], bbox: {
    width: number;
    height: number;
}, node: any) => {
    x: any;
    y: number;
}[];
