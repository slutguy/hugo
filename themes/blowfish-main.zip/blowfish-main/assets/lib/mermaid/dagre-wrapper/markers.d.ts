export default insertMarkers;
declare function insertMarkers(elem: any, markerArray: any, type: any, id: any): void;
