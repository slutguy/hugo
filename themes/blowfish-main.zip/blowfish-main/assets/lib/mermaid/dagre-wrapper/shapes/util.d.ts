/**
 * @param parent
 * @param w
 * @param h
 * @param points
 */
export function insertPolygonShape(parent: any, w: any, h: any, points: any): any;
export function labelHelper(parent: any, node: any, _classes: any, isNode: any): Promise<{
    shapeSvg: any;
    bbox: any;
    halfPadding: number;
    label: any;
}>;
export function updateNodeBounds(node: any, element: any): void;
