export default note;
declare function note(parent: any, node: any): Promise<any>;
