export function insertCluster(elem: any, node: any): void;
export function getClusterTitleWidth(elem: any, node: any): number;
export function clear(): void;
export function positionCluster(node: any): void;
