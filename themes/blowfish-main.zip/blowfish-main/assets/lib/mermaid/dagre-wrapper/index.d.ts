export function render(elem: any, graph: any, markers: any, diagramType: any, id: any): Promise<void>;
