export default createLabel;
/**
 * @param _vertexText
 * @param style
 * @param isTitle
 * @param isNode
 * @deprecated svg-util/createText instead
 */
declare function createLabel(_vertexText: any, style: any, isTitle: any, isNode: any): SVGTextElement | SVGForeignObjectElement;
