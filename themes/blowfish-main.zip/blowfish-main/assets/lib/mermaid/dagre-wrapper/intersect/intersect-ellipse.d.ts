export default intersectEllipse;
/**
 * @param node
 * @param rx
 * @param ry
 * @param point
 */
declare function intersectEllipse(node: any, rx: any, ry: any, point: any): {
    x: any;
    y: any;
};
