export default intersectRect;
declare function intersectRect(node: any, point: any): {
    x: any;
    y: any;
};
