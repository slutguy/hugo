export default intersectCircle;
/**
 * @param node
 * @param rx
 * @param point
 */
declare function intersectCircle(node: any, rx: any, point: any): {
    x: any;
    y: any;
};
