export default intersectNode;
/**
 * @param node
 * @param point
 */
declare function intersectNode(node: any, point: any): any;
