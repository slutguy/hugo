export function insertNode(elem: any, node: any, dir: any): Promise<any>;
export function setNodeElem(elem: any, node: any): void;
export function clear(): void;
export function positionNode(node: any): any;
