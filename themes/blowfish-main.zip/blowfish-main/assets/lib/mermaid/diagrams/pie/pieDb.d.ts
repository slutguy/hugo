import type { PieFields, PieDB } from './pieTypes.js';
import type { RequiredDeep } from 'type-fest';
import type { PieDiagramConfig } from '../../config.type.js';
export declare const DEFAULT_PIE_CONFIG: Required<PieDiagramConfig>;
export declare const DEFAULT_PIE_DB: RequiredDeep<PieFields>;
export declare const db: PieDB;
