import type { Diagram } from '../../Diagram.js';
export declare const draw: (txt: string, id: string, _version: string, diagObj: Diagram) => void;
declare const _default: {
    draw: (txt: string, id: string, _version: string, diagObj: Diagram) => void;
};
export default _default;
