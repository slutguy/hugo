export function setConf(): void;
export function draw(text: any, id: any, _version: any, diagObj: any): void;
declare namespace _default {
    export { setConf };
    export { draw };
}
export default _default;
