/**
 * Draws an info picture in the tag with id: id based on the graph definition in text.
 *
 * @param _text - Mermaid graph definition.
 * @param id - The text for the error
 * @param version - The version
 */
export declare const draw: (_text: string, id: string, version: string) => void;
export declare const renderer: {
    draw: (_text: string, id: string, version: string) => void;
};
export default renderer;
