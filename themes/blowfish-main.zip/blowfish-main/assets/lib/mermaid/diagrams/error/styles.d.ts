export default getStyles;
declare function getStyles(): string;
