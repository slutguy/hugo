import type { DiagramDefinition } from '../../diagram-api/types.js';
declare const diagram: DiagramDefinition;
export default diagram;
