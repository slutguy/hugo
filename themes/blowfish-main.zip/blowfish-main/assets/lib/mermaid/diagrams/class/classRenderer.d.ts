export function draw(text: string, id: string, _version: any, diagObj: any): void;
declare namespace _default {
    export { draw };
}
export default _default;
