import type { DiagramStylesProvider } from '../../diagram-api/types.js';
declare const getStyles: DiagramStylesProvider;
export default getStyles;
