export declare const clear: () => void;
export declare const setAccTitle: (txt: string) => void;
export declare const getAccTitle: () => string;
export declare const setAccDescription: (txt: string) => void;
export declare const getAccDescription: () => string;
export declare const setDiagramTitle: (txt: string) => void;
export declare const getDiagramTitle: () => string;
