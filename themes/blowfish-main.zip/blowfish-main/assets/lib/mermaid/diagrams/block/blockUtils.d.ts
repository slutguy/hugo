export declare const prepareTextForParsing: (text: string) => string;
