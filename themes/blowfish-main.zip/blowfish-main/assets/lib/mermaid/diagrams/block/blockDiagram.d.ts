import type { DiagramDefinition } from '../../diagram-api/types.js';
export declare const diagram: DiagramDefinition;
