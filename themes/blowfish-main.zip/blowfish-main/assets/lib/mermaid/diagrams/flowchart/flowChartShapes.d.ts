/** @param render */
export function addToRender(render: any): void;
/** @param addShape */
export function addToRenderV2(addShape: any): void;
declare namespace _default {
    export { addToRender };
    export { addToRenderV2 };
}
export default _default;
