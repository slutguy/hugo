import type { ExternalDiagramDefinition } from '../../../diagram-api/types.js';
declare const plugin: ExternalDiagramDefinition;
export default plugin;
