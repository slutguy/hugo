import type { ExternalDiagramDefinition } from '../../diagram-api/types.js';
export declare const info: ExternalDiagramDefinition;
