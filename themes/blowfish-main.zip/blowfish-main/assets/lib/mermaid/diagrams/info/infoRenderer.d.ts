import type { DrawDefinition } from '../../diagram-api/types.js';
export declare const renderer: {
    draw: DrawDefinition;
};
