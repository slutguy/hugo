export default getStyles;
declare function getStyles(options: any): string;
