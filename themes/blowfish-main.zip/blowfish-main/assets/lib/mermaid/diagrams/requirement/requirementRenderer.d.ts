export function drawReqs(reqs: any, graph: any, svgNode: any): void;
export function drawElements(els: any, graph: any, svgNode: any): void;
export function draw(text: any, id: any, _version: any, diagObj: any): void;
declare namespace _default {
    export { draw };
}
export default _default;
