declare namespace _default {
    export { ReqMarkers };
    export { insertLineEndings };
}
export default _default;
declare namespace ReqMarkers {
    let CONTAINS: string;
    let ARROW: string;
}
declare function insertLineEndings(parentNode: any, conf: any): void;
