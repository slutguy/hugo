---
title: "使用指南"
description: "Blowfish 的使用指南和教程"

cascade:
  showDate: false
  showAuthor: false
  invertPagination: true
---

{{< lead >}}
Blowfish 的使用指南和教程
{{< /lead >}}

**您是 Blowfish 的用户吗?** 要将您自己编写的指南添加到此列表，请查看[参考模板](/guides/template/)。

本部分包含有关如何配置主题的各种指南。如果您是新用户，请查看 [安装]({{< ref "docs/installation" >}}) 指南或查看 [示例]({{< ref "samples" >}}) 部分来了解 Blowfish 能做出什么效果的网页。

---
