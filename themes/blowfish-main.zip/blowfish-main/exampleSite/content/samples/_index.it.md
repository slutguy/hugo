---
title: "Campioni"
description: "Guarda cosa è possibile fare con Blowfish."

cascade:
  showEdit: false
  showSummary: false
  hideFeatureImage: true

---
{{< lead >}}
Blowfish dà vita ai tuoi contenuti. :heart_eyes:
{{< /lead >}}

Questa sezione contiene alcune pagine demo che mostrano come Blowfish esegue il rendering di diversi tipi di contenuto. Puoi anche vedere una pagina di esempio [elenco tassonomia]({{< ref "tags" >}}).

_**Nota a margine:** Questa pagina è solo un elenco standard di articoli Blowfish e Hugo è stato configurato per generare un tipo di contenuto "campioni" e visualizzare riepiloghi degli articoli._