---
title: Tag

---
Blowfish ha il pieno supporto per le tassonomie Hugo e si adatterà a qualsiasi impostazione tassonomica. Gli elenchi di tassonomia come questo supportano anche il contenuto personalizzato da visualizzare sopra l'elenco dei termini.

Quest'area può essere utilizzata per aggiungere testo descrittivo aggiuntivo a ciascuna tassonomia. Dai un'occhiata al [tag avanzato]({{< ref "advanced" >}}) di seguito per vedere come portare questo concetto ancora oltre.

---
